<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SchoolClass;
use App\Models\Teacher;
use Illuminate\Http\Request;

class SchoolClassController extends Controller
{
    public function index()
    {
        return view('admin.classes.index', [
            'classes' => SchoolClass::with('homeroomTeacher.user')
                ->orderBy('name')
                ->paginate(15)
        ]);
    }

    public function create()
    {
        $teachers = Teacher::with('user')->get();

        return view('admin.classes.create', compact('teachers'));
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'name' => 'required|string|max:50',

            'homeroom_teacher_id' => [
                'nullable',
                'exists:teachers,nip'
            ],

            'academic_year' => [
                'required',
                'string',
                'max:9'
            ],
        ]);

        // class_id tidak auto-increment, jadi dibuat berurutan
        $v['class_id'] = (SchoolClass::max('class_id') ?? 100) + 1;
        (new SchoolClass)->forceFill($v)->save();

        return redirect()
            ->route('admin.classes.index')
            ->with('success', 'Kelas berhasil ditambahkan.');
    }

    public function edit(SchoolClass $class)
    {
        $teachers = Teacher::with('user')->get();

        return view('admin.classes.edit', [
            'schoolClass' => $class,
            'teachers' => $teachers
        ]);
    }

    public function update(Request $request, SchoolClass $class)
    {
        $v = $request->validate([
            'name' => 'required|string|max:50',

            'homeroom_teacher_id' => [
                'nullable',
                'exists:teachers,nip'
            ],

            'academic_year' => [
                'required',
                'string',
                'max:9'
            ],
        ]);

        $class->update($v);

        return redirect()
            ->route('admin.classes.index')
            ->with('success', 'Kelas berhasil diperbarui.');
    }

    public function destroy(SchoolClass $class)
    {
        $class->delete();

        return redirect()
            ->route('admin.classes.index')
            ->with('success', 'Kelas berhasil dihapus.');
    }
}